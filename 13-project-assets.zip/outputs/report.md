# English SMS spam results

- 5574 raw lines; 5135 canonical unique messages after cleaning.
- 4108 training messages; 1027 test messages, including 124 spam.
- Test spam precision: 0.935; recall: 0.927; F1: 0.931.
- Test accuracy: 0.983; majority baseline accuracy: 0.879.
- Majority baseline spam F1: 0.000; 5-fold training CV spam F1: 0.937.

Majority accuracy hides the minority-spam problem, so precision, recall and F1 matter.
Canonical keys lowercase text, normalize whitespace and replace digit sequences; each key
is kept once before splitting, and conflicting-label keys are discarded. No key appears
in both splits. Semantically similar templates may still remain; this is not a temporal,
sender-held-out or real deployment benchmark. Vocabulary and IDF fit only on training folds.
Scores are not calibrated probabilities. Decision threshold is the model default (0.5);
the precision-recall plot is diagnostic, not a threshold tuned against the test set.
Historical English SMS is different from Egyptian Arabic, WhatsApp and current scams.
Do not auto-delete messages. Review false positives and never follow links in raw spam data.

![Evaluation](evaluation.png)
